# VisionAI Studio

Aplicativo web simples para simular criação de vídeos com IA e sistema de login local.

## 🚀 Estrutura
- `login.html`: Tela de login e cadastro.
- `index.html`: Tela principal para criar vídeos.
- `css/`: Estilos visuais do app.
- `js/`: Scripts de comportamento e lógica.

## 💡 Funcionalidades
- Login/cadastro com nome e e-mail.
- Armazenamento local (`localStorage`).
- Simulação de criação de vídeo com IA.
- Interface moderna e responsiva.

## 🧰 Tecnologias
- HTML5  
- CSS3  
- JavaScript (Vanilla)

## 🖥️ Como usar
1. Abra `login.html` no navegador.
2. Faça login (nome + e-mail).
3. Você será redirecionado para o app.
4. Descreva uma ideia e clique em “Gerar Vídeo”.

---

Desenvolvido com 💜 por **Ana & VisionAI Team**               