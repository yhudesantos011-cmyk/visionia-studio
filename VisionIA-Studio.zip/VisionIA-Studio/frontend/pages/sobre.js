export default function Sobre() {
  return (
    <div>
      <h1>Sobre o VisionAI Studio</h1>
      <p>Protótipo de página sobre usando Next.js</p>
    </div>
  );
}
