export default function Home() {
  return (
    <div>
      <h1>VisionAI Studio - Home (Next.js)</h1>
      <p>Bem-vindo ao protótipo do frontend com Next.js</p>
    </div>
  );
}
