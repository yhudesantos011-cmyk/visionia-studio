export default function Contato() {
  return (
    <div>
      <h1>Contato</h1>
      <p>Protótipo de página de contato usando Next.js</p>
    </div>
  );
}
