// Verifica se o usuário está logado
const user = JSON.parse(localStorage.getItem("visionUser"));
const userInfo = document.getElementById("userInfo");

if (!user) {
  window.location.href = "login.html";
} else {
  userInfo.innerText = `Olá, ${user.name}! 👋`;
}

document.getElementById("generateBtn").addEventListener("click", () => {
  const prompt = document.getElementById("videoPrompt").value.trim();
  const result = document.getElementById("result");

  if (!prompt) {
    alert("Digite uma ideia para o vídeo!");
    return;
  }

  result.innerHTML = `<p>🎥 Gerando vídeo com IA para: <strong>${prompt}</strong>...</p>
                      <p>⏳ Isso pode levar alguns segundos...</p>`;

  setTimeout(() => {
    result.innerHTML = `<p>✅ Seu vídeo foi gerado com sucesso!</p>
                        <p><em>(Simulação concluída)</em></p>`;
  }, 3000);
});
