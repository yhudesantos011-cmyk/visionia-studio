const express = require('express');
const app = express();
const projectsRouter = require('./routes/projects');
require('dotenv').config();

app.use(express.json());
app.use('/api/projects', projectsRouter);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
