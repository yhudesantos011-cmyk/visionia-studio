const express = require('express');
const router = express.Router();

// GET /api/projects
router.get('/', (req, res) => {
    res.json({ message: "Lista de projetos de vídeo (mock)" });
});

module.exports = router;
