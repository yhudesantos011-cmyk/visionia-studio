// Simulação de worker para processar vídeos
function processVideo(project) {
    console.log(`Processando vídeo para o projeto: ${project.name}`);
}

module.exports = { processVideo };
